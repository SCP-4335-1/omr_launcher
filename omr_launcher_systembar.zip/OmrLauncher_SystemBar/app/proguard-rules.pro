# Add project specific ProGuard rules here.
-keep class com.omarchy.launcher.data.** { *; }
