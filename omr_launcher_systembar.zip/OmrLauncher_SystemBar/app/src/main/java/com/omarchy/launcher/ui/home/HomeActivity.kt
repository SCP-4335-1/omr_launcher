package com.omarchy.launcher.ui.home

import android.app.WallpaperManager
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.widget.PopupWindow
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.viewpager2.widget.ViewPager2
import com.omarchy.launcher.LauncherApplication
import com.omarchy.launcher.R
import com.omarchy.launcher.data.AppInfo
import com.omarchy.launcher.databinding.ActivityHomeBinding
import com.omarchy.launcher.gesture.LauncherGestureDetector
import com.omarchy.launcher.ui.SettingsActivity
import com.omarchy.launcher.ui.menu.OmarchyMenuBuilder
import com.omarchy.launcher.util.GlitchEffectHelper

private const val GRID_COLUMNS = 5
private const val GRID_ROWS = 6
private const val DOCK_DEFAULT_SIZE = 5

/**
 * The actual HOME activity. Registered with category.HOME in the
 * manifest, launchMode singleTask so re-pressing Home never stacks a
 * second instance on top of itself.
 *
 * Responsibilities deliberately centralized here rather than split into
 * fragments: a launcher's home screen has exactly one instance for the
 * lifetime of the foreground session, so fragment lifecycle overhead
 * buys nothing -- plain view-binding + a shared ViewModel is enough.
 */
class HomeActivity : AppCompatActivity(), LauncherGestureDetector.Callback {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var gestureDetector: LauncherGestureDetector

    private val viewModel: HomeViewModel by viewModels {
        val app = LauncherApplication.from(this)
        HomeViewModel.Factory(app.appRepository, app.layoutStore)
    }

    private var drawerOpen = false
    private var omarchyMenuOpen = false
    private var walkerLauncherOpen = false
    private var pagerAdapter: HomePagerAdapter? = null

    private val widgetPickerLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val appWidgetId = result.data?.getIntExtra(
                android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID, -1
            ) ?: -1
            if (appWidgetId != -1) {
                // Widget placement onto the grid is a v1.1 follow-up: for
                // now we confirm the binding succeeded. Wiring this into
                // HomeGridLayout as a WIDGET-type HomeItem follows the
                // exact same addAppToHome() pattern used for app icons.
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        gestureDetector = LauncherGestureDetector(this, this)

        setupWallpaper()
        setupGestureCapture()
        setupDrawer()
        setupOmarchyMenu()
        setupWalkerLauncher()
        observeViewModel()
    }

    // ---- Wallpaper -----------------------------------------------------

    private fun setupWallpaper() {
        try {
            val wallpaperManager = WallpaperManager.getInstance(this)
            val drawable: Drawable? = wallpaperManager.drawable
            binding.wallpaperView.setImageDrawable(drawable)
        } catch (e: Exception) {
            // No wallpaper permission / no wallpaper set -- the void-black
            // theme background already looks intentional on its own.
        }
    }

    // ---- Gesture capture -------------------------------------------------
    // Using dispatchTouchEvent at the Activity level instead of a touch
    // listener on the root view: a listener on rootHome only sees events
    // the ViewPager2/HomeGridLayout children haven't already consumed,
    // which is exactly what was breaking swipe-up before (the pager's own
    // vertical/horizontal touch handling ate the gesture first).
    // dispatchTouchEvent always sees every event before any child does.

    private fun setupGestureCapture() {
        // no-op now; gesture feed happens in dispatchTouchEvent override below
    }

    override fun dispatchTouchEvent(event: android.view.MotionEvent): Boolean {
        if (!walkerLauncherOpen && !omarchyMenuOpen) {
            gestureDetector.onTouchEvent(event)
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onSwipeUp() {
        if (!drawerOpen && !omarchyMenuOpen && !walkerLauncherOpen) openDrawer()
    }

    override fun onSwipeDown() {
        if (drawerOpen) closeDrawer()
    }

    override fun onDoubleTap() {
        if (!drawerOpen && !omarchyMenuOpen && !walkerLauncherOpen) {
            openOmarchyMenu()
        }
    }

    override fun onLongPress(x: Float, y: Float) {
        if (!drawerOpen) showHomeContextMenu(x, y)
    }

    override fun onSingleTapConfirmed() {
        if (drawerOpen) closeDrawer()
    }

    // ---- Drawer ----------------------------------------------------------

    private fun setupDrawer() {
        binding.appDrawerView.onAppClick = { app ->
            GlitchEffectHelper.playTapGlitch(binding.appDrawerView)
            viewModel.launchApp(app)
            closeDrawer()
        }
        binding.appDrawerView.onAppLongClick = { app, anchor ->
            showAppContextMenu(app, anchor, allowRemoveFromHome = false)
        }
        binding.appDrawerView.onWebSearch = { query ->
            performWebSearch(query)
            closeDrawer()
        }

        // Primary, always-visible affordance to open the drawer -- the
        // swipe-up gesture still works, but a button you can actually
        // see and tap is what makes the drawer discoverable at all.
        binding.drawerOpenButton.setOnClickListener {
            if (drawerOpen) closeDrawer() else openDrawer()
        }
        binding.drawerPullTab.setOnClickListener {
            if (drawerOpen) closeDrawer() else openDrawer()
        }
    }

    private fun openDrawer() {
        drawerOpen = true
        binding.drawerContainer.visibility = View.VISIBLE
        binding.appDrawerView.resetSearch()
        GlitchEffectHelper.playDrawerOpenGlitch(binding.drawerContainer)
    }

    private fun closeDrawer() {
        drawerOpen = false
        binding.drawerContainer.visibility = View.INVISIBLE
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Re-pressing Home while already in the launcher (singleTask
        // brings this same instance back) should always land on the
        // plain homescreen -- close every overlay rather than leaving
        // the drawer/menu sitting open underneath.
        if (walkerLauncherOpen) closeWalkerLauncher()
        if (omarchyMenuOpen) closeOmarchyMenu()
        if (drawerOpen) closeDrawer()
    }

    override fun onBackPressed() {
        if (walkerLauncherOpen) {
            closeWalkerLauncher()
        } else if (omarchyMenuOpen) {
            binding.omarchyMenuView.handleBackPressed()
        } else if (drawerOpen) {
            closeDrawer()
        } else {
            // Home is the base of the task stack -- there is intentionally
            // nothing "back" to navigate to, matching real launcher behavior.
            moveTaskToBack(true)
        }
    }

    // ---- Omarchy menu (wofi/walker-style, double-tap to open) -------------

    private fun setupOmarchyMenu() {
        binding.omarchyMenuView.onRequestClose = { closeOmarchyMenu() }

        // Tapping the scrim outside the centered popup closes the menu,
        // same as clicking outside a wofi/walker window.
        binding.omarchyMenuOverlay.setOnClickListener { closeOmarchyMenu() }
    }

    private fun openOmarchyMenu() {
        val builder = OmarchyMenuBuilder(
            context = this,
            onOpenWalkerLauncher = { openWalkerLauncher() },
            onOpenSettings = { startActivity(Intent(this, SettingsActivity::class.java)) },
            onOpenWallpaperPicker = { openWallpaperPicker() },
            onOpenWidgetPicker = { openWidgetPicker() },
            onCloseMenu = { closeOmarchyMenu() }
        )

        omarchyMenuOpen = true
        binding.omarchyMenuOverlay.visibility = View.VISIBLE
        binding.omarchyMenuView.open(
            getString(R.string.omarchy_menu_title_main),
            builder.buildMainMenu()
        )
        GlitchEffectHelper.playDrawerOpenGlitch(binding.omarchyMenuView)
    }

    private fun closeOmarchyMenu() {
        omarchyMenuOpen = false
        binding.omarchyMenuOverlay.visibility = View.GONE
    }

    // ---- Walker-style app launcher (Omarchy menu's "Apps" entry) ----------

    private fun setupWalkerLauncher() {
        binding.walkerLauncherView.onLaunchApp = { app -> viewModel.launchApp(app) }
        binding.walkerLauncherView.onRequestClose = { closeWalkerLauncher() }

        // Tapping the scrim outside the centered box closes it, same as
        // clicking outside walker's own window.
        binding.walkerLauncherOverlay.setOnClickListener { closeWalkerLauncher() }
    }

    private fun openWalkerLauncher() {
        walkerLauncherOpen = true
        binding.walkerLauncherOverlay.visibility = View.VISIBLE
        binding.walkerLauncherView.open(viewModel.allApps.value.orEmpty())
        GlitchEffectHelper.playDrawerOpenGlitch(binding.walkerLauncherView)
    }

    private fun closeWalkerLauncher() {
        walkerLauncherOpen = false
        binding.walkerLauncherOverlay.visibility = View.GONE
    }

    // ---- ViewModel / pager wiring -----------------------------------------

    private fun observeViewModel() {
        viewModel.allApps.observe(this, Observer { apps ->
            binding.appDrawerView.submitApps(apps)
            updateDockFromTopApps(apps)
        })

        viewModel.pageCount.observe(this, Observer { count ->
            setupPager(count)
        })

        viewModel.homeItems.observe(this, Observer {
            pagerAdapter?.notifyDataSetChanged()
        })
    }

    private fun setupPager(pageCount: Int) {
        pagerAdapter = HomePagerAdapter(
            pageCount = pageCount,
            columns = GRID_COLUMNS,
            rows = GRID_ROWS,
            itemsByPage = { page -> viewModel.itemsForPage(page) },
            iconResolver = { pkg, activity -> viewModel.resolveApp(pkg, activity) },
            onAppClick = { app ->
                viewModel.launchApp(app)
            },
            onAppLongClick = { app, anchor ->
                showAppContextMenu(app, anchor, allowRemoveFromHome = true)
            },
            onEmptyCellLongClick = { _, x, y, _ ->
                showHomeContextMenu(x.toFloat(), y.toFloat())
            }
        )
        binding.homePager.adapter = pagerAdapter
        binding.homePager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updatePageIndicator(position, pageCount)
            }
        })
        updatePageIndicator(binding.homePager.currentItem, pageCount)
    }

    private fun updatePageIndicator(current: Int, total: Int) {
        val sb = StringBuilder("[")
        for (i in 0 until total) {
            sb.append(if (i == current) "*" else "-")
        }
        sb.append("]")
        binding.pageIndicator.text = sb.toString()
    }

    private fun updateDockFromTopApps(apps: List<AppInfo>) {
        if (apps.isNotEmpty()) renderDock()
    }

    private fun renderDock() {
        val dockApps = viewModel.recentApps(DOCK_DEFAULT_SIZE)
        binding.dockView.setApps(dockApps)
        binding.dockView.onAppClickListener = { app -> viewModel.launchApp(app); renderDock() }
        binding.dockView.onAppLongClickListener = { app, anchor ->
            showAppContextMenu(app, anchor, allowRemoveFromHome = false)
        }
    }

    // ---- Context menus ----------------------------------------------------

    private fun showHomeContextMenu(x: Float, y: Float) {
        val popupView = layoutInflater.inflate(R.layout.popup_home_context_menu, binding.rootHome, false)
        val popup = PopupWindow(
            popupView,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )

        popupView.findViewById<android.widget.TextView>(R.id.menuWidgets).setOnClickListener {
            popup.dismiss()
            openWidgetPicker()
        }
        popupView.findViewById<android.widget.TextView>(R.id.menuWallpaper).setOnClickListener {
            popup.dismiss()
            openWallpaperPicker()
        }
        popupView.findViewById<android.widget.TextView>(R.id.menuSettings).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        popup.showAtLocation(binding.rootHome, android.view.Gravity.NO_GRAVITY, x.toInt(), y.toInt())
    }

    private fun showAppContextMenu(app: AppInfo, anchor: View, allowRemoveFromHome: Boolean) {
        val popupView = layoutInflater.inflate(R.layout.popup_app_context_menu, binding.rootHome, false)
        val popup = PopupWindow(
            popupView,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )

        popupView.findViewById<android.widget.TextView>(R.id.menuAppLabel).text = app.label
        popupView.findViewById<android.widget.TextView>(R.id.menuPinHome).setOnClickListener {
            popup.dismiss()
            val (freeCol, freeRow) = findNextFreeCell(binding.homePager.currentItem)
            viewModel.addAppToHome(app, page = binding.homePager.currentItem, col = freeCol, row = freeRow)
            closeDrawer()
        }
        popupView.findViewById<android.widget.TextView>(R.id.menuAppInfo).setOnClickListener {
            popup.dismiss()
            viewModel.openAppInfo(app)
        }
        popupView.findViewById<android.widget.TextView>(R.id.menuUninstall).setOnClickListener {
            popup.dismiss()
            try {
                val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE).apply {
                    data = android.net.Uri.parse("package:${app.packageName}")
                    putExtra(Intent.EXTRA_RETURN_RESULT, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            } catch (e: Exception) {
                // System uninstall UI unavailable (rare OEM lockdown) --
                // fail quietly rather than crashing the whole launcher.
            }
        }
        val removeView = popupView.findViewById<android.widget.TextView>(R.id.menuRemove)
        if (allowRemoveFromHome) {
            removeView.visibility = View.VISIBLE
            removeView.setOnClickListener {
                popup.dismiss()
                // Item id lookup by package/activity on the current page;
                // good enough since duplicate placements of the same app
                // across the grid are rare and each occurrence removes
                // independently if tapped directly.
                viewModel.itemsForPage(binding.homePager.currentItem)
                    .firstOrNull { it.packageName == app.packageName && it.activityName == app.activityName }
                    ?.let { viewModel.removeHomeItem(it.id) }
            }
        }

        val location = IntArray(2)
        anchor.getLocationOnScreen(location)
        popup.showAtLocation(binding.rootHome, android.view.Gravity.NO_GRAVITY, location[0], location[1])
    }

    // ---- Widgets / wallpaper launchers ------------------------------------

    /**
     * Mirrors typing a non-app query into a walker/spotlight-style
     * launcher: ACTION_WEB_SEARCH hands the query straight to whatever
     * the user has set as their default search provider/browser, which
     * is the standard, most broadly-supported way to do this on Android
     * (works the same on stock Android and Samsung's OneUI skin).
     */
    private fun performWebSearch(query: String) {
        try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(android.app.SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback: open a search-engine URL directly in the browser
            // if no ACTION_WEB_SEARCH handler exists on this device.
            try {
                val fallback = Intent(Intent.ACTION_VIEW).apply {
                    data = android.net.Uri.parse(
                        "https://www.google.com/search?q=${android.net.Uri.encode(query)}"
                    )
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(fallback)
            } catch (e2: Exception) {
                // No browser at all on this device -- nothing more we can do.
            }
        }
    }

    private fun openWidgetPicker() {
        widgetPickerLauncher.launch(
            Intent(this, com.omarchy.launcher.ui.widgets.WidgetPickerActivity::class.java)
        )
    }

    private fun openWallpaperPicker() {
        com.omarchy.launcher.ui.wallpaper.WallpaperPickerDialog.show(
            context = this,
            anchor = binding.rootHome,
            onPresetApplied = { setupWallpaper() }
        )
    }

    /**
     * Finds the first unoccupied cell on the given page, scanning
     * row-major (left-to-right, top-to-bottom). Falls back to (0,0) if
     * the page is completely full -- pinning then just overlaps the
     * first icon rather than throwing, since a full 5x6 grid (30 apps
     * pinned to one page) is already an edge case the user would notice
     * and fix themselves by adding a page.
     */
    private fun findNextFreeCell(page: Int): Pair<Int, Int> {
        val occupied = viewModel.itemsForPage(page).map { it.col to it.row }.toSet()
        for (row in 0 until GRID_ROWS) {
            for (col in 0 until GRID_COLUMNS) {
                if ((col to row) !in occupied) return col to row
            }
        }
        return 0 to 0
    }

    override fun onResume() {
        super.onResume()
        setupWallpaper()
        renderDock()
    }

    override fun onPause() {
        super.onPause()
    }
}
