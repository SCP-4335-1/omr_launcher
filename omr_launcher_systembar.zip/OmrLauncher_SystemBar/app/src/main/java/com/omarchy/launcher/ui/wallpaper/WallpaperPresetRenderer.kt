package com.omarchy.launcher.ui.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.DisplayMetrics

/** Draws a WallpaperPreset to a full-screen-sized Bitmap and applies it via WallpaperManager. */
object WallpaperPresetRenderer {

    fun apply(context: Context, preset: WallpaperPreset): Boolean {
        return try {
            val metrics: DisplayMetrics = context.resources.displayMetrics
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            val gradient = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                preset.topColor, preset.bottomColor,
                Shader.TileMode.CLAMP
            )
            val paint = Paint().apply { shader = gradient }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

            val linePaint = Paint().apply {
                color = preset.accentColor
                alpha = 28
                strokeWidth = 2f
            }
            val cols = 6
            for (i in 1 until cols) {
                val x = width * i / cols.toFloat()
                canvas.drawLine(x, 0f, x, height.toFloat(), linePaint)
            }

            WallpaperManager.getInstance(context).setBitmap(bitmap)
            true
        } catch (e: Exception) {
            false
        }
    }
}
