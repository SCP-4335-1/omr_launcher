# omr_launcher

Ein Android-Homescreen-Launcher im **Omarchy/Hyprland-Terminal-Look**
(dunkel, monospace, Neon-Akzente, dezente Glitch-Effekte) mit
**Nova-Launcher-artiger Funktionalität**: echter `HOME`-Intent,
App-Drawer mit umschaltbarer Terminal-Listen-/Neon-Grid-Ansicht,
Gesten (Swipe-Up/Down, Doppeltipp, Long-Press), Homescreen-Grid mit
freier Icon-Platzierung, Dock, Widget-Host und Layout-Backup/Restore.

## Setup

1. **Android Studio öffnen**: Ordner direkt als Projekt öffnen lassen
   ("Open" → diesen Ordner wählen). Android Studio generiert beim
   ersten Sync automatisch den `gradlew`-Wrapper — dieses Repo enthält
   ihn bewusst nicht als Binärdatei, nur die Konfiguration dafür
   (`gradle/wrapper/gradle-wrapper.properties`).

2. **Alternativ über die Kommandozeile**:
   ```bash
   ./build.sh debug      # baut app/build/outputs/apk/debug/app-debug.apk
   ./build.sh install    # baut + installiert auf verbundenem Gerät/Emulator
   ./build.sh release    # unsigniertes Release-APK
   ./build.sh clean
   ```
   Voraussetzung: ein lokal installiertes `gradle` (für den
   Erst-Bootstrap des Wrappers) und ein Android SDK (`ANDROID_SDK_ROOT`
   gesetzt oder eine `local.properties` mit `sdk.dir=...`).

3. **Nach dem Build installieren**: APK auf das Gerät übertragen,
   installieren, dann unter **Einstellungen → Apps → Standard-Apps →
   Startbildschirm-App** `omr_launcher` als Standard wählen (oder beim
   Drücken der Home-Taste erscheint automatisch die App-Auswahl).

## Architektur-Überblick

```
data/          AppInfo, HomeItem, AppRepository (LauncherApps-API),
               LayoutStore (JSON-Persistenz via SharedPreferences)
gesture/       LauncherGestureDetector (Swipe/DoubleTap/LongPress)
ui/home/       HomeActivity, HomeViewModel, HomeGridLayout (Custom
               ViewGroup mit freier Zellplatzierung + Drag&Drop),
               HomePagerAdapter, DockView, GridOverlayView
ui/drawer/     AppDrawerView (Such-/Filter-Logik + Modus-Umschaltung),
               TerminalListAdapter (ls -la-Stil), NeonGridAdapter
ui/widgets/    WidgetHostManager (AppWidgetHost-Kapselung),
               WidgetPickerActivity (Picker- + Konfigurations-Flow)
ui/            SettingsActivity (PreferenceFragmentCompat,
               launcher.conf-Stil, inkl. Backup/Restore)
util/          GlitchEffectHelper, DeviceLockUtil, DeviceAdminReceiver
```

## Features (v1)

- Echte `HOME`-Intent-Registrierung (`launchMode="singleTask"`)
- App-Liste über `LauncherApps`-API (Multi-Profil-fähig, reagiert auf
  Installation/Deinstallation live)
- App-Drawer mit Suche + zwei umschaltbaren Ansichten:
  - **Terminal-Liste**: `ls -la`-Stil mit Fake-Permission-Bits
  - **Neon-Grid**: Icons mit Glow-Rahmen + Tap-Glitch-Animation
- Homescreen-Grid mit freier Icon-Platzierung (Col/Row-basiert,
  überlebt Auflösungswechsel)
- Dock (feste Favoriten-Leiste, editierbar)
- Gesten: Swipe-Up (Drawer öffnen), Swipe-Down (Drawer schließen),
  **Doppeltipp auf leerem Homescreen-Bereich öffnet das Omarchy-Menü**
  (siehe unten), Long-Press (Kontextmenüs)
- **Permanenter, sichtbarer Drawer-Öffner**: ein eigener Button im Dock
  (rechts) sowie ein Pull-Tab direkt über dem Dock -- der Drawer ist
  jetzt nicht mehr nur über die unsichtbare Swipe-Geste erreichbar
- **Omarchy-Menü** (wofi/walker-Style, wie `omarchy-menu` unter
  Hyprland): zentriertes Popup mit Suchfeld und Drill-down-Navigation
  durch Apps/Style/Setup/Widgets/About/System. Öffnet sich per
  Doppeltipp auf einen leeren Bereich des Homescreens (nicht in anderen
  Apps, da die Geste nur innerhalb der Launcher-Activity registriert
  ist) und schließt per Tap auf den Hintergrund, Zurück-Taste, oder
  Auswahl eines Eintrags
- Widget-Picker-Flow (Auswahl + Konfigurationsactivity), Platzierung
  auf dem Grid ist als nächster Schritt vorbereitet (siehe unten)
- Settings im `launcher.conf`-Stil: Grid-Größe, Drawer-Default-Modus,
  Glitch-FX/Scanlines-Toggle, Akzentfarbe, Backup/Restore (Export als
  Klartext-String über die Zwischenablage)
- Hyprland-artiges Gitterlinien-Overlay auf dem Homescreen

## Omarchy-Menü: Struktur

Nachgebaut nach der echten Struktur von
[`basecamp/omarchy/bin/omarchy-menu`](https://github.com/basecamp/omarchy/blob/dev/bin/omarchy-menu),
aber auf Android-sinnvolle Aktionen abgebildet (es gibt kein `pacman`,
keine Hyprland-Configs auf dem Handy):

```
omarchy-menu
├── Apps           → öffnet den echten App-Drawer + Schnellzugriff auf die ersten Apps
├── Style          → Wallpaper, Launcher-Settings, Display-Settings
├── Setup          → Wi-Fi, Bluetooth, Sound, Default-Apps, alle Settings
├── Widgets        → Add widget…
├── About          → Versionsinfo, App-Info
└── System         → Lock
```

Jede Zeile mit `›` am Ende ist ein Untermenü (drillt rein), alle
anderen führen die Aktion sofort aus und schließen das Menü. Die
Suchleiste filtert live innerhalb der aktuellen Ebene (kein globales
Fuzzy-Matching über alle Ebenen wie bei `walker`, aber funktional
gleichwertig für den Scope hier).

**Icons**: Das echte Omarchy-Menü nutzt Nerd-Font-Glyphen (Private-Use-
Area-Codepoints). Da ich keine Font-Binärdatei einbetten kann, sind die
Icons hier auf reguläre Unicode-Symbole (▦ ◐ ⚙ etc.) umgestellt, die
ohne zusätzliche Font garantiert korrekt rendern.

## Bekannte Lücken / nächste Schritte

Ich habe das gesamte Projekt von Hand geschrieben und alle
Ressourcen-Referenzen gegeneinander geprüft, konnte es aber **ohne
Android SDK/Gradle in meiner Umgebung nicht tatsächlich kompilieren**.
Folgendes solltest du beim ersten Build im Blick haben:

1. **Widget-Platzierung aufs Grid**: `WidgetPickerActivity` liefert
   bereits eine fertig gebundene `appWidgetId` zurück. Das tatsächliche
   Einfügen als `WIDGET`-Item in `HomeGridLayout` ist in
   `HomeActivity.widgetPickerLauncher` als Kommentar markiert -- folgt
   exakt dem Muster von `addAppToHome()`, nutzt aber
   `WidgetHostManager.createHostView()` statt eines Icon-Views.

2. **Ordner (Folders)**: `HomeItem` hat bereits `folderItemIds`
   vorgesehen, aber es gibt noch keine Folder-UI/Adapter. Drag eines
   Icons auf ein anderes (über `HomeGridLayout`s Drag&Drop) wäre der
   natürliche Trigger dafür.

3. **Drag&Drop zum Neu-Anordnen**: `HomeGridLayout` hat die
   `OnDragListener`-Logik (`ACTION_DROP` -> Zielzelle berechnen), aber
   `HomeActivity`/`HomePagerAdapter` starten noch keinen
   `View.startDragAndDrop()` bei Long-Press auf ein platziertes Icon.
   Aktuell öffnet Long-Press nur das Kontextmenü.

4. **Icon-Pack-Support**: in den Settings als Preference-Kategorie
   vorgesehen (`pref_icon_pack` fehlt noch als Eintrag), aber das
   Auslesen fremder Icon-Pack-APKs (z. B. ADW/Nova-Format) ist nicht
   implementiert.

5. **JetBrains Mono**: Da ich keine Font-Binärdatei einbetten kann,
   fällt die App auf System-`monospace` zurück. Für den authentischen
   Look: `JetBrainsMono-Regular.ttf` (OFL-Lizenz, von
   jetbrains.com/lp/mono) in `app/src/main/res/font/` ablegen, eine
   `font-family`-XML dafür anlegen und in `themes.xml` referenzieren.

6. **ViewBinding-Feldnamen**: `HomeActivity` nutzt `binding.xyz` für
   alle IDs aus `activity_home.xml` -- diese werden von AGP automatisch
   aus den `android:id`-Werten generiert (camelCase). Sollte passen,
   aber bei einem ersten Sync-Fehler ist das der erste Verdächtige.

## Berechtigungen, die der Nutzer ggf. manuell erteilen muss

- **Standard-Launcher setzen**: Android fragt das automatisch ab, wenn
  die App installiert ist und Home gedrückt wird.
- **Device-Admin für Doppeltipp-Lock**: ohne diese Freigabe ist die
  Geste ein No-Op (kein Crash, kein ungewolltes Popup) -- bewusst so
  gebaut, da es keine andere öffentliche API für Launcher gibt, um den
  Screen ohne explizite Nutzerfreigabe zu sperren.
- **Wallpaper setzen**: über `ACTION_SET_WALLPAPER`, leitet an die
  Standard-Galerie/Wallpaper-App des Systems weiter.
