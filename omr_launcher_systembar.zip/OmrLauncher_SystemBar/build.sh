#!/usr/bin/env bash
#
# build.sh -- builds the omr_launcher debug APK.
#
# This project ships with settings.gradle.kts / build.gradle.kts but
# NOT a binary gradlew script (those are large generated binaries and
# don't survive being hand-typed reliably). This script bootstraps the
# wrapper using a system-installed `gradle`, then always builds through
# the wrapper afterwards, matching how Android Studio itself would set
# the project up on first open.
#
# Usage:
#   ./build.sh            # debug build
#   ./build.sh release    # release build (unsigned)
#   ./build.sh clean      # clean build outputs
#
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

MODE="${1:-debug}"

echo "==> omr_launcher build script"
echo "==> project dir: $PROJECT_DIR"

# --- 1. Ensure the Gradle wrapper exists ------------------------------------
if [ ! -f "./gradlew" ]; then
    echo "==> gradlew not found, bootstrapping wrapper..."
    if ! command -v gradle >/dev/null 2>&1; then
        echo "ERROR: no system 'gradle' found and no gradlew present."
        echo "Install Gradle (e.g. 'sdkmanager', your package manager, or"
        echo "via https://gradle.org/install/) and re-run this script,"
        echo "or open this folder directly in Android Studio, which will"
        echo "generate the wrapper automatically on first sync."
        exit 1
    fi
    gradle wrapper --gradle-version 8.7
    chmod +x ./gradlew
fi

# --- 2. Sanity-check Android SDK location -----------------------------------
if [ -z "${ANDROID_SDK_ROOT:-}" ] && [ -z "${ANDROID_HOME:-}" ] && [ ! -f "local.properties" ]; then
    echo "WARNING: ANDROID_SDK_ROOT / ANDROID_HOME not set and no local.properties found."
    echo "If the build fails with 'SDK location not found', create local.properties:"
    echo '  echo "sdk.dir=/path/to/Android/sdk" > local.properties'
fi

# --- 3. Run the requested Gradle task ---------------------------------------
case "$MODE" in
    debug)
        echo "==> building debug APK..."
        ./gradlew assembleDebug --console=plain
        echo ""
        echo "==> done. APK at: app/build/outputs/apk/debug/app-debug.apk"
        ;;
    release)
        echo "==> building (unsigned) release APK..."
        ./gradlew assembleRelease --console=plain
        echo ""
        echo "==> done. APK at: app/build/outputs/apk/release/app-release-unsigned.apk"
        echo "    (unsigned -- sign it before installing on a non-debug device)"
        ;;
    clean)
        echo "==> cleaning..."
        ./gradlew clean --console=plain
        ;;
    install)
        echo "==> building + installing debug APK to connected device..."
        ./gradlew installDebug --console=plain
        ;;
    *)
        echo "Unknown mode: $MODE"
        echo "Usage: ./build.sh [debug|release|clean|install]"
        exit 1
        ;;
esac
